#ifndef __PARSE_H
#define __PARSE_H

#include <QString>
#include <QBluetoothAddress>
#include "iodev.h"


bool ParseConnection(QString str,ConnectionData &conn);



#endif // PARSE_H
